
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface ProductsSectionProps {
  language: 'CAT' | 'ESP';
}

const content = {
  CAT: {
    title: "Productes",
    description: "Descobreix la nostra col·lecció de productes inspirats en Maria Anna Mozart. Cada article inclou una etiqueta amb un codi QR que enllaça a aquesta pàgina i el mantra de Nannerl.",
    products: [
      {
        name: "Tassa",
        description: "Tassa de ceràmica amb la il·lustració de Maria Anna Mozart.",
        label: "Properament"
      },
      {
        name: "Llibreta", 
        description: "Llibreta amb la il·lustració de Maria Anna Mozart a la portada.",
        label: "Properament"
      },
      {
        name: "Làmina",
        description: "Làmina d'art amb la il·lustració de Maria Anna Mozart.",
        label: "Properament"
      }
    ],
    tagTitle: "Etiqueta de producte"
  },
  ESP: {
    title: "Productos",
    description: "Descubre nuestra colección de productos inspirados en Maria Anna Mozart. Cada artículo incluye una etiqueta con un código QR que enlaza a esta página y el mantra de Nannerl.",
    products: [
      {
        name: "Taza",
        description: "Taza de cerámica con la ilustración de Maria Anna Mozart.",
        label: "Próximamente"
      },
      {
        name: "Libreta",
        description: "Libreta con la ilustración de Maria Anna Mozart en la portada.",
        label: "Próximamente"
      },
      {
        name: "Lámina",
        description: "Lámina de arte con la ilustración de Maria Anna Mozart.",
        label: "Próximamente"
      }
    ],
    tagTitle: "Etiqueta de producto"
  }
};

export const ProductsSection = ({ language }: ProductsSectionProps) => {
  return (
    <section className="py-20 px-4 bg-background">
      <div className="container max-w-6xl mx-auto">
        <div className="text-left mb-16">
          <h2 className="text-4xl font-bold mb-6">
            {content[language].title}
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl">
            {content[language].description}
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 mb-20">
          {content[language].products.map((product, index) => (
            <Card key={index} className="text-center">
              <CardHeader>
                <div className="w-32 h-32 mx-auto mb-4 bg-muted rounded-lg flex items-center justify-center">
                  {index === 0 && (
                    <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-purple-800 rounded-full flex items-center justify-center">
                      <div className="w-8 h-8 bg-white rounded-sm"></div>
                    </div>
                  )}
                  {index === 1 && (
                    <div className="w-20 h-14 bg-gradient-to-br from-purple-600 to-purple-800 rounded-sm"></div>
                  )}
                  {index === 2 && (
                    <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-purple-800 rounded-full"></div>
                  )}
                </div>
                <CardTitle>{product.name}</CardTitle>
                <CardDescription>{product.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="outline" disabled>
                  {product.label}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="bg-muted/30 rounded-lg p-8">
          <h3 className="text-2xl font-bold mb-8 text-left">
            {content[language].tagTitle}
          </h3>
          
          <div className="flex flex-col md:flex-row items-center justify-center gap-8">
            <div className="w-32 h-32 bg-white rounded-lg shadow-lg flex items-center justify-center">
              {/* QR Code representation */}
              <div className="grid grid-cols-8 gap-1 w-20 h-20">
                {Array.from({ length: 64 }, (_, i) => (
                  <div
                    key={i}
                    className={`w-2 h-2 ${
                      Math.random() > 0.6 ? 'bg-black' : 'bg-white'
                    }`}
                  />
                ))}
              </div>
            </div>
            
            <div className="flex-1 max-w-md">
              <blockquote className="border-l-4 border-primary pl-4">
                <p className="text-lg italic text-muted-foreground mb-2">
                  "{language === 'CAT' 
                    ? 'La música és el meu refugi, però el deure d\'una dona és callar. Potser algun dia les meves composicions seran recordades, igual que les del meu estimat germà.'
                    : 'La música es mi refugio, pero el deber de una mujer es callar. Quizás algún día mis composiciones sean recordadas, igual que las de mi querido hermano.'
                  }"
                </p>
                <cite className="text-sm font-semibold">
                  — Maria Anna "Nannerl" Mozart
                </cite>
              </blockquote>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
