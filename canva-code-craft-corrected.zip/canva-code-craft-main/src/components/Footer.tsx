
import { Facebook, Instagram, Twitter } from "lucide-react";

interface FooterProps {
  language: 'CAT' | 'ESP';
}

const content = {
  CAT: {
    title: "Maria Anna Mozart",
    subtitle: "Recuperant la memòria d'una gènia oblidada",
    copyright: "© 2023 Tots els drets reservats"
  },
  ESP: {
    title: "Maria Anna Mozart", 
    subtitle: "Recuperando la memoria de una genio olvidada",
    copyright: "© 2023 Todos los derechos reservados"
  }
};

export const Footer = ({ language }: FooterProps) => {
  return (
    <footer className="bg-black text-white py-12 px-4">
      <div className="container max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <div>
            <h3 className="text-2xl font-bold mb-2">
              {content[language].title}
            </h3>
            <p className="text-white/80">
              {content[language].subtitle}
            </p>
          </div>
          
          <div className="flex gap-6">
            <a 
              href="#" 
              className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors"
              aria-label="Facebook"
            >
              <Facebook size={20} />
            </a>
            <a 
              href="#" 
              className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors"
              aria-label="Instagram"
            >
              <Instagram size={20} />
            </a>
            <a 
              href="#" 
              className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors"
              aria-label="Twitter"
            >
              <Twitter size={20} />
            </a>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-white/20 text-center">
          <p className="text-white/60">
            {content[language].copyright}
          </p>
        </div>
      </div>
    </footer>
  );
};
