

interface TimelineSectionProps {
  language: 'CAT' | 'ESP';
}

const content = {
  CAT: {
    title: "Cronologia",
    events: [
      {
        year: "1751",
        description: "Naixement a Salzburg, Àustria"
      },
      {
        year: "1759", 
        description: "Comença la seva formació musical amb el seu pare"
      },
      {
        year: "1762-1773",
        description: "Gires musicals per Europa amb el seu germà"
      },
      {
        year: "1769",
        description: "Fi de su carrera pública como intérprete"
      },
      {
        year: "1784",
        description: "Matrimoni amb Johann Baptist Franz von Berchtold"
      },
      {
        year: "1801",
        description: "Mort del seu marit, torna a Salzburg"
      },
      {
        year: "1829",
        description: "Mort a Salzburg als 78 anys"
      }
    ]
  },
  ESP: {
    title: "Cronología",
    events: [
      {
        year: "1751",
        description: "Nacimiento en Salzburgo, Austria"
      },
      {
        year: "1759",
        description: "Comienza su formación musical con su padre"
      },
      {
        year: "1762-1773",
        description: "Giras musicales por Europa con su hermano"
      },
      {
        year: "1769",
        description: "Fin de su carrera pública como intérprete"
      },
      {
        year: "1784",
        description: "Matrimonio con Johann Baptist Franz von Berchtold"
      },
      {
        year: "1801",
        description: "Muerte de su marido, regresa a Salzburgo"
      },
      {
        year: "1829",
        description: "Muerte en Salzburgo a los 78 años"
      }
    ]
  }
};

export const TimelineSection = ({ language }: TimelineSectionProps) => {
  return (
    <section className="py-20 px-4 bg-white">
      <div className="container max-w-6xl mx-auto">
        {/* Mobile layout - vertical timeline */}
        
    <div className="block lg:hidden">
      <h2 className="text-3xl font-bold mb-8 text-black">{content[language].title}</h2>
      <div className="relative border-l-2 border-black pl-6 space-y-6 text-black">
        {content[language].events.map((event, index) => (
          <div key={index} className="ml-2">
            <div className="font-bold">{event.year}</div>
            <p>{event.description}</p>
          </div>
        ))}
      </div>
      return null;
    
          <h2 className="text-5xl font-bold text-left mb-16 text-black">
            {content[language].title}
          </h2>
          <div className="relative">
            <div className="absolute left-8 top-0 bottom-0 w-px bg-black"></div>
            
            <div className="space-y-12">
              {content[language].events.map((event, index) => (
                <div key={index} className="relative flex items-start gap-8">
                  <div className="w-4 h-4 bg-black rounded-full border-4 border-white shadow-lg flex-shrink-0 mt-1"></div>
                  
                  <div className="flex-grow">
                    <h3 className="text-2xl font-bold text-black mb-2">
                      {event.year}
                    </h3>
                    <p className="text-black text-lg font-light leading-relaxed">
                      {event.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Desktop layout - 2 columns with text on left, timeline on right */}
        <div className="hidden lg:grid lg:grid-cols-2 lg:gap-16">
          {/* Left column - Biography text continuation */}
          <div className="space-y-8">
            <div className="text-black text-lg font-light leading-relaxed">
              {language === 'CAT' ? (
                <p>
                  Entre 1762 i 1773, els germans Mozart van realitzar diverses gires per Europa, actuant davant de la noblesa i la realesa. Nannerl era aclamada com una virtuosa del clavicordi i el fortepiano, a menudo rebent elogis iguals o superiors als del seu germà.
                </p>
              ) : (
                <p>
                  Entre 1762 y 1773, los hermanos Mozart realizaron diversas giras por Europa, actuando ante la nobleza y la realeza. Nannerl era aclamada como una virtuosa del clavicordio y el fortepiano, a menudo recibiendo elogios iguales o superiores a los de su hermano.
                </p>
              )}
            </div>
            
            <div>
              <h3 className="text-4xl font-bold mb-6 text-black text-left">
                {language === 'CAT' ? 'El silenci imposat' : 'El silencio impuesto'}
              </h3>
              <div className="text-black text-lg font-light leading-relaxed space-y-6">
                {language === 'CAT' ? (
                  <>
                    <p>
                      Malgrat el seu talent excepcional, la carrera musical de Nannerl va ser truncada abruptament quan va arribar a l'edat de casar-se. Segons les convencions socials de l'època, no era apropiat que una dona de classe mitjana-alta continués actuant en públic o es dediqués professionalment a la música.
                    </p>
                    <p>
                      Mentre el seu germà Wolfgang continuava la seva carrera musical amb el suport total del seu pare, Nannerl va ser obligada a quedar-se a casa per aprendre les tasques domèstiques i preparar-se per al matrimoni. El seu pare va deixar d'invertir en la seva educació musical i va centrar tots els seus esforços en promoure la carrera del seu fill.
                    </p>
                    <p>
                      Aquest contrast dramàtic en el tractament dels dos germans il·lustra clarament les restriccions de gènere de l'època. Malgrat tenir un talent comparable al del seu germà, a Nannerl se li va negar l'oportunitat de desenvolupar plenament el seu potencial artístic simplement per ser dona.
                    </p>
                  </>
                ) : (
                  <>
                    <p>
                      A pesar de su talento excepcional, la carrera musical de Nannerl fue truncada abruptamente cuando llegó a la edad de casarse. Según las convenciones sociales de la época, no era apropiado que una mujer de clase media-alta continuara actuando en público o se dedicara profesionalmente a la música.
                    </p>
                    <p>
                      Mientras su hermano Wolfgang continuaba su carrera musical con el apoyo total de su padre, Nannerl fue obligada a quedarse en casa para aprender las tareas domésticas y prepararse para el matrimonio. Su padre dejó de invertir en su educación musical y centró todos sus esfuerzos en promover la carrera de su hijo.
                    </p>
                    <p>
                      Este contraste dramático en el tratamiento de los dos hermanos ilustra claramente las restricciones de género de la época. A pesar de tener un talento comparable al de su hermano, a Nannerl se le negó la oportunidad de desarrollar plenamente su potencial artístico simplemente por ser mujer.
                    </p>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Right column - Timeline */}
          <div className="space-y-8">
            <h2 className="text-5xl font-bold text-left text-black">
              {content[language].title}
            </h2>
            
            <div className="space-y-8">
              {content[language].events.map((event, index) => (
                <div key={index} className="flex items-start gap-4">
                  <div className="w-3 h-3 bg-black rounded-full flex-shrink-0 mt-2"></div>
                  <div className="flex-grow">
                    <h3 className="text-2xl font-bold text-black mb-2">
                      {event.year}
                    </h3>
                    <p className="text-black text-lg font-light leading-relaxed">
                      {event.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
