
import { Button } from "@/components/ui/button";
import { MariaAnnaIllustration } from "./MariaAnnaIllustration";

interface HeroSectionProps {
  language: 'CAT' | 'ESP';
}

const content = {
  CAT: {
    title: "Maria Anna Mozart",
    subtitle: "La germana oblidada del geni",
    quote: "La música és el meu refugi, però el deure d'una dona és callar. Potser algun dia les meves composicions seran recordades, igual que les del meu estimat germà.",
    button: "Descobreix la seva història"
  },
  ESP: {
    title: "Maria Anna Mozart",
    subtitle: "La hermana olvidada del genio", 
    quote: "La música es mi refugio, pero el deber de una mujer es callar. Quizás algún día mis composiciones sean recordadas, igual que las de mi querido hermano.",
    button: "Descubre su historia"
  }
};

export const HeroSection = ({ language }: HeroSectionProps) => {
  const scrollToNext = () => {
    const nextSection = document.getElementById('biografia');
    nextSection?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="min-h-screen flex items-center justify-center px-4 py-12 bg-gradient-to-br from-background to-muted/20">
      <div className="container max-w-6xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-5xl lg:text-7xl font-bold text-foreground leading-tight">
                {content[language].title}
              </h1>
              <p className="text-xl text-muted-foreground">
                {content[language].subtitle}
              </p>
            </div>
            
            <blockquote className="border-l-4 border-primary pl-6 py-4 bg-muted/30 rounded-r-lg">
              <p className="text-lg italic text-muted-foreground leading-relaxed">
                "{content[language].quote}"
              </p>
            </blockquote>
            
            <Button 
              onClick={scrollToNext}
              size="lg" 
              className="bg-black text-white hover:bg-black/90 rounded-full px-8 py-4 text-lg"
            >
              {content[language].button}
            </Button>
          </div>
          
          <div className="flex justify-center">
            <MariaAnnaIllustration />
          </div>
        </div>
      </div>
    </section>
  );
};
