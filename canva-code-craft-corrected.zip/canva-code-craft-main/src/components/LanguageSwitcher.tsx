
import { Switch } from "@/components/ui/switch";

interface LanguageSwitcherProps {
  language: 'CAT' | 'ESP';
  onLanguageChange: (language: 'CAT' | 'ESP') => void;
}

export const LanguageSwitcher = ({ language, onLanguageChange }: LanguageSwitcherProps) => {
  const handleSwitchChange = (checked: boolean) => {
    onLanguageChange(checked ? 'ESP' : 'CAT');
  };

  return (
    <div className="flex items-center gap-2 bg-white/90 backdrop-blur-sm rounded-full px-4 py-2 shadow-lg">
      <span className={`text-sm font-medium ${language === 'CAT' ? 'text-primary' : 'text-muted-foreground'}`}>
        CAT
      </span>
      <Switch 
        checked={language === 'ESP'} 
        onCheckedChange={handleSwitchChange}
        className="data-[state=checked]:bg-primary"
      />
      <span className={`text-sm font-medium ${language === 'ESP' ? 'text-primary' : 'text-muted-foreground'}`}>
        ESP
      </span>
    </div>
  );
};
