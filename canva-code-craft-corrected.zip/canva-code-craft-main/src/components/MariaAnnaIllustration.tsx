
export const MariaAnnaIllustration = () => {
  return (
    <div className="relative w-80 h-80 lg:w-96 lg:h-96">
      {/* Background circle */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-100 to-purple-50 rounded-full shadow-lg"></div>
      
      {/* Maria Anna figure */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="relative">
          {/* Hair */}
          <div className="w-32 h-32 bg-amber-800 rounded-full relative">
            {/* Hair ribbons */}
            <div className="absolute -left-2 top-6 w-3 h-8 bg-black rounded-sm transform -rotate-12"></div>
            <div className="absolute -right-2 top-6 w-3 h-8 bg-black rounded-sm transform rotate-12"></div>
            <div className="absolute -left-1 top-12 w-3 h-8 bg-black rounded-sm transform -rotate-45"></div>
            <div className="absolute -right-1 top-12 w-3 h-8 bg-black rounded-sm transform rotate-45"></div>
          </div>
          
          {/* Face */}
          <div className="absolute top-4 left-4 w-24 h-28 bg-amber-50 rounded-full">
            {/* Eyes */}
            <div className="absolute top-8 left-5 w-2 h-2 bg-black rounded-full"></div>
            <div className="absolute top-8 right-5 w-2 h-2 bg-black rounded-full"></div>
            
            {/* Nose */}
            <div className="absolute top-12 left-1/2 transform -translate-x-1/2 w-1 h-2 bg-amber-100 rounded-full"></div>
            
            {/* Smile */}
            <div className="absolute top-16 left-1/2 transform -translate-x-1/2 w-6 h-3 border-b-2 border-black rounded-full"></div>
          </div>
          
          {/* Necklace */}
          <div className="absolute top-28 left-1/2 transform -translate-x-1/2 w-20 h-1 bg-yellow-400 rounded-full"></div>
          
          {/* Dress */}
          <div className="absolute top-32 left-1/2 transform -translate-x-1/2 w-40 h-48 bg-gradient-to-b from-purple-600 to-purple-800 rounded-t-full"></div>
        </div>
      </div>
    </div>
  );
};
