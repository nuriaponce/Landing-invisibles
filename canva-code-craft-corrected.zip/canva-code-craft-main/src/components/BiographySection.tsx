

interface BiographySectionProps {
  language: 'CAT' | 'ESP';
}

const content = {
  CAT: {
    title: "Biografia",
    nannerl: {
      title: 'La prodigiosa "Nannerl"',
      text: "Maria Anna Walburga Ignatia Mozart, coneguda afectuosament com a \"Nannerl\", va néixer el 30 de juliol de 1751 a Salzburg, Àustria. Filla de Leopold i Anna Maria Mozart, va ser la germana gran de Wolfgang Amadeus Mozart.\nDes de molt jove, Nannerl va demostrar un talent musical extraordinari. El seu pare, Leopold Mozart, un reconegut músic i pedagog, va començar a ensenyar-li a tocar el clavicordi quan només tenia set anys. La seva habilitat era tan impressionant que aviat va començar a actuar en concerts juntament amb el seu germà petit."
    },
    forgotten: {
      title: "El llegat oblidat",
      text: "Hi ha evidències que Nannerl també va compondre música. El seu germà Wolfgang menciona les seves composicions en diverses cartes, elogiant el seu talent. En una carta de 1770, escriu: \"La meva germana és increïblement hàbil... ha escrit algunes composicions realment boniques\".\nMalauradament, cap de les seves composicions ha sobreviscut fins als nostres dies. En una època en què les dones no eren considerades creadores serioses, és probable que les seves obres no fossin preservades amb la mateixa cura que les del seu germà."
    }
  },
  ESP: {
    title: "Biografía",
    nannerl: {
      title: 'La prodigiosa "Nannerl"',
      text: "Maria Anna Walburga Ignatia Mozart, conocida cariñosamente como \"Nannerl\", nació el 30 de julio de 1751 en Salzburgo, Austria. Hija de Leopold y Anna Maria Mozart, fue la hermana mayor de Wolfgang Amadeus Mozart.\nDesde muy joven, Nannerl demostró un talento musical extraordinario. Su padre, Leopold Mozart, un reconocido músico y pedagogo, comenzó a enseñarle a tocar el clavicordio cuando solo tenía siete años. Su habilidad era tan impresionante que pronto comenzó a actuar en conciertos junto con su hermano pequeño."
    },
    forgotten: {
      title: "El legado olvidado",
      text: "Hay evidencias de que Nannerl también compuso música. Su hermano Wolfgang menciona sus composiciones en diversas cartas, elogiando su talento. En una carta de 1770, escribe: \"Mi hermana es increíblemente hábil... ha escrito algunas composiciones realmente hermosas\".\nDesafortunadamente, ninguna de sus composiciones ha sobrevivido hasta nuestros días. En una época en que las mujeres no eran consideradas creadoras serias, es probable que sus obras no fueran preservadas con el mismo cuidado que las de su hermano."
    }
  }
};

export const BiographySection = ({ language }: BiographySectionProps) => {
  return (
    <div className="text-black">
    <section id="biografia" className="py-20 px-4 bg-white">
      <div className="container max-w-6xl mx-auto">
        <h2 className="text-5xl font-bold text-left mb-16 text-black">
          {content[language].title}
        </h2>
        
        <div className="grid md:grid-cols-2 gap-16">
          <div>
            <h3 className="text-4xl font-bold mb-6 text-black text-left">
              {content[language].nannerl.title}
            </h3>
            <div className="text-black text-lg font-light leading-relaxed whitespace-pre-line">
              {content[language].nannerl.text}
            </div>
          </div>
          
          <div>
            <h3 className="text-4xl font-bold mb-6 text-black text-left">
              {content[language].forgotten.title}
            </h3>
            <div className="text-black text-lg font-light leading-relaxed whitespace-pre-line">
              {content[language].forgotten.text}
            </div>
          </div>
        </div>
      </div>
        </div>
  </section>
  );
};
