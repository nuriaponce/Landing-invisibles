
import { useState } from "react";
import { HeroSection } from "@/components/HeroSection";
import { BiographySection } from "@/components/BiographySection";
import { TimelineSection } from "@/components/TimelineSection";
import { ProductsSection } from "@/components/ProductsSection";
import { Footer } from "@/components/Footer";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";

const Index = () => {
  const [language, setLanguage] = useState<'CAT' | 'ESP'>('CAT');

  return (
    <div className="min-h-screen bg-background">
      <div className="fixed top-4 right-4 z-50">
        <LanguageSwitcher language={language} onLanguageChange={setLanguage} />
      </div>
      
      <HeroSection language={language} />
      <BiographySection language={language} />
      <TimelineSection language={language} />
      <ProductsSection language={language} />
      <Footer language={language} />
    </div>
  );
};

export default Index;
