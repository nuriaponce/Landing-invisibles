
import { LanguageProvider } from '@/hooks/useLanguage';
import LanguageSwitcher from '@/components/LanguageSwitcher';
import HeroSection from '@/components/HeroSection';
import BiographySection from '@/components/BiographySection';
import ProductsSection from '@/components/ProductsSection';
import Footer from '@/components/Footer';

const Index = () => {
  return (
    <LanguageProvider>
      <div className="min-h-screen font-helvetica">
        <LanguageSwitcher />
        <HeroSection />
        <BiographySection />
        <ProductsSection />
        <Footer />
      </div>
    </LanguageProvider>
  );
};

export default Index;
