import { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'CAT' | 'ESP';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  CAT: {
    subtitle: "La germana oblidada del geni",
    quote: "La música és el meu refugi, però el deure d'una dona és callar. Potser algun dia les meves composicions seran recordades, igual que les del meu estimat germà.",
    discoverButton: "Descobreix la seva història",
    productsTitle: "Productes",
    productsDescription: "Descobreix la nostra col·lecció de productes inspirats en Maria Anna Mozart. Cada article inclou una etiqueta amb un codi QR que enllaça a aquesta pàgina i el mantra de Nannerl.",
    biographyTitle: "Biografia",
    prodigious: "La prodigiosa \"Nannerl\"",
    prodigiousText: "Maria Anna Walburga Ignatia Mozart, coneguda afectuosament com a \"Nannerl\", va néixer el 30 de juliol de 1751 a Salzburg, Àustria. Filla de Leopold i Anna Maria Mozart, va ser la germana gran de Wolfgang Amadeus Mozart.\n\nDes de molt jove, Nannerl va demostrar un talent musical extraordinari. El seu pare, Leopold Mozart, un reconegut músic i pedagog, va començar a ensenyar-li a tocar el clavicordi quan només tenia set anys. La seva habilitat era tan impressionant que aviat va començar a actuar en concerts juntament amb el seu germà petit.\n\nEntre 1762 i 1773, els germans Mozart van realitzar diverses gires per Europa, actuant davant de la noblesa i la reialesa. Nannerl era aclamada com una virtuosa del clavicordi i el fortepiano, sovint rebent elogis iguals o superiors als del seu germà.",
    forgottenLegacy: "El llegat oblidat",
    forgottenText: "Hi ha evidències que Nannerl també va compondre música. El seu germà Wolfgang menciona les seves composicions en diverses cartes, elogiant el seu talent. En una carta de 1770, escriu: \"La meva germana és increïblement hàbil... ha escrit algunes composicions realment boniques\".\n\nMalauradament, cap de les seves composicions ha sobreviscut fins als nostres dies. En una època en què les dones no eren considerades creadores serioses, és probable que les seves obres no fossin preservades amb la mateixa cura que les del seu germà.\n\nEl 1784, als 33 anys, Nannerl es va casar amb Johann Baptist Franz von Berchtold zu Sonnenburg, un magistrat amb cinc fills d'anteriors matrimonis. Va tenir tres fills propis, incloent-hi un fill anomenat Leopold després del seu pare.\n\nDesprés de la mort del seu marit el 1801, Nannerl va tornar a Salzburg on va donar classes de música. Va morir el 29 d'octubre de 1829, als 78 anys.",
    imposedSilence: "El silenci imposat",
    imposedText: "Malgrat el seu talent excepcional, la carrera musical de Nannerl va ser truncada abruptament quan va arribar a l'edat de casar-se. Segons les convencions socials de l'època, no era apropiat que una dona de classe mitjana-alta continués actuant en públic o es dediqués professionalment a la música.\n\nMentre el seu germà Wolfgang continuava la seva carrera musical amb el suport total del seu pare, Nannerl va ser obligada a quedar-se a casa per aprendre les tasques domèstiques i preparar-se per al matrimoni. El seu pare va deixar d'invertir en la seva educació musical i va concentrar tots els esforços en la carrera del seu fill.\n\nAquest contrast dramàtic en el tractament dels dos germans il·lustra clarament les restriccions de gènere de l'època. Malgrat tenir un talent comparable al del seu germà, a Nannerl se li va negar l'oportunitat de desenvolupar plenament el seu potencial artístic simplement per ser dona.",
    chronologyTitle: "Cronologia",
    timeline: {
      1751: "Naixement a Salzburg, Àustria",
      1759: "Comença la seva formació musical amb el seu pare",
      "1762-1773": "Gires musicals per Europa amb el seu germà",
      1769: "Fi de la seva carrera pública com a intèrpret",
      1784: "Matrimoni amb Johann Baptist Franz von Berchtold",
      1801: "Mort del seu marit, torna a Salzburg",
      1829: "Mort a Salzburg als 78 anys"
    },
    productLabels: {
      cup: "Tassa",
      cupDescription: "Tassa de ceràmica amb la il·lustració de Maria Anna Mozart.",
      notebook: "Libreta",
      notebookDescription: "Libreta amb la il·lustració de Maria Anna Mozart a la portada.",
      lamp: "Làmina",
      lampDescription: "Làmina d'art amb la il·lustració de Maria Anna Mozart.",
      coming: "Properament"
    },
    podcastTitle: "🎙️ La veu de les invisibles",
    podcastDescription: "Escolta el podcast d'IN·VISIBLES: històries breus, intenses i reals de dones que van deixar empremta en el món tot i que la història les va esborrar.",
    podcastEpisode: "En el primer episodi coneixeràs la vida de Maria Anna \"Nannerl\" Mozart, més enllà del seu cognom.",
    podcastButton: "Escolta el primer episodi",
    footerMainText: "Darrere de cada dona que dibuixem hi ha una història real que mereix ser explicada. IN·VISIBLES és un projecte per donar veu a aquelles que van ser silenciades, ignorades o esborrades de la història.\n\nPerquè el que no s'explica, s'oblida. I nosaltres volem recordar.",
    footerIncoherent: "Un projecte de in.coherent, perquè fins i tot les accions més petites poden fer un món més just.",
    footerCopyright2025: "© 2025 IN·VISIBLES · Tots els drets reservats"
  },
  ESP: {
    subtitle: "La hermana olvidada del genio",
    quote: "La música es mi refugio, pero el deber de una mujer es callar. Quizás algún día mis composiciones sean recordadas, al igual que las de mi querido hermano.",
    discoverButton: "Descubre su historia",
    productsTitle: "Productos",
    productsDescription: "Descubre nuestra colección de productos inspirados en Maria Anna Mozart. Cada artículo incluye una etiqueta con un código QR que enlaza a esta página y el mantra de Nannerl.",
    biographyTitle: "Biografía",
    prodigious: "La prodigiosa \"Nannerl\"",
    prodigiousText: "Maria Anna Walburga Ignatia Mozart, conocida cariñosamente como \"Nannerl\", nació el 30 de julio de 1751 en Salzburgo, Austria. Hija de Leopold y Anna Maria Mozart, fue la hermana mayor de Wolfgang Amadeus Mozart.\n\nDesde muy joven, Nannerl demostró un talento musical extraordinario. Su padre, Leopold Mozart, un reconocido músico y pedagogo, comenzó a enseñarle a tocar el clavicordio cuando solo tenía siete años. Su habilidad era tan impresionante que pronto comenzó a actuar en conciertos junto con su hermano pequeño.\n\nEntre 1762 y 1773, los hermanos Mozart realizaron diversas giras por Europa, actuando ante la nobleza y la realeza. Nannerl era aclamada como una virtuosa del clavicordio y el fortepiano, a menudo recibiendo elogios iguales o superiores a los de su hermano.",
    forgottenLegacy: "El legado olvidado",
    forgottenText: "Hay evidencias de que Nannerl también componía música. Su hermano Wolfgang menciona sus composiciones en diversas cartas, elogiando su talento. En una carta de 1770, escribe: \"Mi hermana es increíblemente hábil... ha escrito algunas composiciones realmente hermosas\".\n\nLamentablemente, ninguna de sus composiciones ha sobrevivido hasta nuestros días. En una época en que las mujeres no eran consideradas creadoras serias, es probable que sus obras no fueran preservadas con el mismo cuidado que las de su hermano.\n\nEn 1784, a los 33 años, Nannerl se casó con Johann Baptist Franz von Berchtold zu Sonnenburg, un magistrado con cinco hijos de matrimonios anteriores. Tuvo tres hijos propios, incluyendo un hijo llamado Leopold en honor a su padre.\n\nTras la muerte de su marido en 1801, Nannerl regresó a Salzburgo donde dio clases de música. Murió el 29 de octubre de 1829, a los 78 años.",
    imposedSilence: "El silencio impuesto",
    imposedText: "A pesar de su talento excepcional, la carrera musical de Nannerl fue truncada abruptamente cuando llegó a la edad de casarse. Según las convenciones sociales de la época, no era apropiado que una mujer de clase media-alta continuara actuando en público o se dedicara profesionalmente a la música.\n\nMientras su hermano Wolfgang continuaba su carrera musical con el apoyo total de su padre, Nannerl fue obligada a quedarse en casa para aprender las tareas domésticas y prepararse para el matrimonio. Su padre dejó de invertir en su educación musical y concentró todos los esfuerzos en la carrera de su hijo.\n\nEste contraste dramático en el tratamiento de los dos hermanos ilustra claramente las restricciones de género de la época. A pesar de tener un talento comparable al de su hermano, a Nannerl se le negó la oportunidad de desarrollar plenamente su potencial artístico simplemente por ser mujer.",
    chronologyTitle: "Cronología",
    timeline: {
      1751: "Nacimiento en Salzburgo, Austria",
      1759: "Comienza su formación musical con su padre",
      "1762-1773": "Giras musicales por Europa con su hermano",
      1769: "Fin de su carrera pública como intérprete",
      1784: "Matrimonio con Johann Baptist Franz von Berchtold",
      1801: "Muerte de su marido, regresa a Salzburgo",
      1829: "Muerte en Salzburgo a los 78 años"
    },
    productLabels: {
      cup: "Taza",
      cupDescription: "Taza de cerámica con la ilustración de Maria Anna Mozart.",
      notebook: "Libreta",
      notebookDescription: "Libreta con la ilustración de Maria Anna Mozart en la portada.",
      lamp: "Lámina",
      lampDescription: "Lámina de arte con la ilustración de Maria Anna Mozart.",
      coming: "Próximamente"
    },
    podcastTitle: "🎙️ La voz de las invisibles",
    podcastDescription: "Escucha el podcast de IN·VISIBLES: historias breves, intensas y reales de mujeres que dejaron huella en el mundo aunque la historia las borró.",
    podcastEpisode: "En el primer episodio conocerás la vida de Maria Anna \"Nannerl\" Mozart, más allá de su apellido.",
    podcastButton: "Escucha el primer episodio",
    footerMainText: "Detrás de cada mujer que dibujamos hay una historia real que merece ser contada. IN·VISIBLES es un proyecto para dar voz a aquellas que fueron silenciadas, ignoradas o borradas de la historia.\n\nPorque lo que no se cuenta, se olvida. Y nosotros queremos recordar.",
    footerIncoherent: "Un proyecto de in.coherent, porque incluso las acciones más pequeñas pueden hacer un mundo más justo.",
    footerCopyright2025: "© 2025 IN·VISIBLES · Todos los derechos reservados"
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [language, setLanguage] = useState<Language>('CAT');

  const t = (key: string): string => {
    const keys = key.split('.');
    let value: any = translations[language];
    
    for (const k of keys) {
      value = value?.[k];
    }
    
    return value || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
