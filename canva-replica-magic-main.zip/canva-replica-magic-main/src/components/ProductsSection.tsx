
import { useLanguage } from '@/hooks/useLanguage';

const ProductsSection = () => {
  const { t } = useLanguage();

  const products = [
    {
      name: t('productLabels.cup'),
      description: t('productLabels.cupDescription'),
      image: 'cup'
    },
    {
      name: t('productLabels.notebook'),
      description: t('productLabels.notebookDescription'),
      image: 'notebook'
    },
    {
      name: t('productLabels.lamp'),
      description: t('productLabels.lampDescription'),
      image: 'lamp'
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-6 lg:px-12">
        <h2 className="text-5xl lg:text-6xl font-helvetica font-bold text-black mb-8">
          {t('productsTitle')}
        </h2>
        
        <p className="text-lg font-helvetica font-light text-black leading-relaxed mb-12 max-w-4xl">
          {t('productsDescription')}
        </p>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {products.map((product, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden">
              <div className="h-64 bg-gray-200 flex items-center justify-center">
                {/* Product placeholder */}
                <div className="w-32 h-32 bg-gray-300 rounded-lg flex items-center justify-center">
                  {product.image === 'cup' && (
                    <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center">
                      <div className="w-4 h-4 bg-purple-600 rounded-full"></div>
                    </div>
                  )}
                  {product.image === 'notebook' && (
                    <div className="w-16 h-20 bg-purple-600 rounded"></div>
                  )}
                  {product.image === 'lamp' && (
                    <div className="w-20 h-20 bg-purple-600 rounded-full"></div>
                  )}
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-helvetica font-bold text-black mb-2">
                  {product.name}
                </h3>
                <p className="text-lg font-helvetica font-light text-black leading-relaxed mb-4">
                  {product.description}
                </p>
                <button className="text-lg font-helvetica font-bold text-black hover:text-purple-600 transition-colors">
                  {t('productLabels.coming')}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Podcast Section */}
        <section className="bg-white p-6 rounded-lg shadow-md my-10">
          <h2 className="text-2xl font-bold mb-4">{t('podcastTitle')}</h2>
          <p className="text-gray-700 mb-4 leading-relaxed">
            {t('podcastDescription')}
            <br /><br />
            <span dangerouslySetInnerHTML={{ __html: t('podcastEpisode') }} />
          </p>

          <button className="inline-block mt-4 px-6 py-2 bg-black text-white font-semibold rounded hover:bg-gray-800 transition">
            {t('productLabels.coming')}
          </button>
        </section>
      </div>
    </section>
  );
};

export default ProductsSection;
