import { useLanguage } from '@/hooks/useLanguage';

const BiographySection = () => {
  const { t } = useLanguage();

  const chronologyEvents = [
    { year: '1751', event: t('timeline.1751') },
    { year: '1759', event: t('timeline.1759') },
    { year: '1762-1773', event: t('timeline.1762-1773') },
    { year: '1769', event: t('timeline.1769') },
    { year: '1784', event: t('timeline.1784') },
    { year: '1801', event: t('timeline.1801') },
    { year: '1829', event: t('timeline.1829') }
  ];

  return (
    <section id="biography" className="py-16 bg-white">
      <div className="container mx-auto px-6 lg:px-12">
        <h2 className="text-4xl lg:text-5xl font-helvetica font-bold text-black mb-12">
          {t('biographyTitle')}
        </h2>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Left Column - Prodigious and Imposed Silence */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl lg:text-3xl font-helvetica font-bold text-black mb-6">
                {t('prodigious')}
              </h3>
              <div className="space-y-4 text-lg font-helvetica font-light text-black leading-relaxed">
                {t('prodigiousText').split('\n\n').map((paragraph, index) => (
                  <p key={index}>{paragraph}</p>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-2xl lg:text-3xl font-helvetica font-bold text-black mb-6">
                {t('imposedSilence')}
              </h3>
              <div className="space-y-4 text-lg font-helvetica font-light text-black leading-relaxed">
                {t('imposedText').split('\n\n').map((paragraph, index) => (
                  <p key={index}>{paragraph}</p>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column - Forgotten Legacy and Chronology */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl lg:text-3xl font-helvetica font-bold text-black mb-6">
                {t('forgottenLegacy')}
              </h3>
              <div className="space-y-4 text-lg font-helvetica font-light text-black leading-relaxed">
                {t('forgottenText').split('\n\n').map((paragraph, index) => (
                  <p key={index}>{paragraph}</p>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-2xl lg:text-3xl font-helvetica font-bold text-black mb-8">
                {t('chronologyTitle')}
              </h3>
              <div className="relative">
                <div className="absolute left-2 top-0 bottom-0 w-0.5 bg-black"></div>
                <div className="space-y-8">
                  {chronologyEvents.map((event, index) => (
                    <div key={index} className="relative pl-8">
                      <div className="absolute left-0 w-4 h-4 bg-black rounded-full -translate-x-1/2"></div>
                      <div>
                        <h4 className="text-xl font-helvetica font-bold text-black mb-2">
                          {event.year}
                        </h4>
                        <p className="text-base font-helvetica font-light text-black leading-relaxed">
                          {event.event}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BiographySection;
