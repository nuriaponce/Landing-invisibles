
import { useLanguage } from '@/hooks/useLanguage';

const HeroSection = () => {
  const { t } = useLanguage();

  const scrollToBiography = () => {
    const biographySection = document.getElementById('biography');
    if (biographySection) {
      biographySection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="min-h-screen bg-gray-50 flex items-center">
      <div className="container mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Mobile Illustration - Only visible on mobile */}
          <div className="flex justify-center lg:hidden order-1">
            <div className="w-80 h-80 relative">
              <img 
                src="/lovable-uploads/fed1e97d-c367-4a1b-a906-63d3c107062e.png" 
                alt="Maria Anna Mozart illustration"
                className="w-full h-full object-contain drop-shadow-md"
              />
            </div>
          </div>

          {/* Left Content */}
          <div className="space-y-8 order-2 lg:order-1">
            <div>
              <h1 className="text-5xl lg:text-6xl font-helvetica font-bold text-black leading-tight">
                Maria Anna Mozart
              </h1>
              <p className="text-xl lg:text-2xl font-helvetica font-light text-black mt-6 leading-relaxed">
                {t('subtitle')}
              </p>
            </div>

            <blockquote className="border-l-4 border-black pl-6 italic text-lg font-helvetica font-light text-black leading-relaxed">
              "{t('quote')}"
            </blockquote>

            <button 
              onClick={scrollToBiography}
              className="bg-black text-white px-8 py-4 rounded-full font-helvetica font-regular text-lg hover:bg-gray-800 transition-colors"
            >
              {t('discoverButton')}
            </button>
          </div>

          {/* Desktop Illustration - Only visible on desktop */}
          <div className="hidden lg:flex justify-center order-3 lg:order-2">
            <div className="w-96 h-96 lg:w-[500px] lg:h-[500px] relative">
              <img 
                src="/lovable-uploads/fed1e97d-c367-4a1b-a906-63d3c107062e.png" 
                alt="Maria Anna Mozart illustration"
                className="w-full h-full object-contain drop-shadow-md"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
