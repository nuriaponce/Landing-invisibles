
import { useLanguage } from '@/hooks/useLanguage';

const Footer = () => {
  const { t } = useLanguage();

  return (
    <footer className="bg-black text-white py-10 px-6 text-sm md:text-base">
      <div className="max-w-4xl mx-auto">
        
        {/* IN·VISIBLES */}
        <h3 className="text-2xl font-bold mb-4 tracking-tight">IN·VISIBLES</h3>
        <p className="text-gray-300 leading-relaxed">
          {t('footerMainText')}
        </p>

        {/* in.coherent */}
        <div className="mt-8 text-sm text-gray-400">
          {t('footerIncoherent')}
        </div>

        {/* Crèdits */}
        <div className="mt-10 border-t border-gray-700 pt-6 text-center text-gray-500 text-xs">
          {t('footerCopyright2025')} · 
          <a href="https://instagram.com/in.visibles" target="_blank" rel="noopener noreferrer" className="hover:text-white underline">
            Instagram
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
