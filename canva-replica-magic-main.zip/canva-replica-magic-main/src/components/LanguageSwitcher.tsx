
import { useLanguage } from '@/hooks/useLanguage';

const LanguageSwitcher = () => {
  const { language, setLanguage } = useLanguage();

  return (
    <div className="fixed top-4 right-4 z-50 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2 shadow-sm">
      <div className="flex items-center gap-1 text-sm font-helvetica font-bold">
        <button
          onClick={() => setLanguage('CAT')}
          className={`px-2 py-1 rounded transition-colors ${
            language === 'CAT' 
              ? 'text-black' 
              : 'text-gray-400 hover:text-gray-600'
          }`}
        >
          CAT
        </button>
        <span className="text-gray-300">|</span>
        <button
          onClick={() => setLanguage('ESP')}
          className={`px-2 py-1 rounded transition-colors ${
            language === 'ESP' 
              ? 'text-black' 
              : 'text-gray-400 hover:text-gray-600'
          }`}
        >
          ESP
        </button>
      </div>
    </div>
  );
};

export default LanguageSwitcher;
