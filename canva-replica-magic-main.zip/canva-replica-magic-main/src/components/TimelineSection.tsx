
import { useLanguage } from '@/hooks/useLanguage';

const TimelineSection = () => {
  const { t } = useLanguage();

  const timelineEvents = [
    { year: '1784', event: t('timeline.1784') },
    { year: '1801', event: t('timeline.1801') },
    { year: '1829', event: t('timeline.1829') }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Left Text */}
          <div className="space-y-6">
            <p className="text-lg font-helvetica font-light text-black leading-relaxed">
              Aquest contrast dramàtic en el tractament dels dos germans il·lustra clarament les restriccions de gènere de l'època. Malgrat tenir un talent comparable al del seu germà, a Nannerl se li va negar l'oportunitat de desenvolupar plenament el seu potencial artístic simplement per ser dona.
            </p>
          </div>

          {/* Right Timeline */}
          <div className="space-y-6">
            <div className="relative">
              <div className="absolute left-2 top-0 bottom-0 w-0.5 bg-black"></div>
              <div className="space-y-8">
                {timelineEvents.map((event, index) => (
                  <div key={index} className="relative pl-8">
                    <div className="absolute left-0 w-4 h-4 bg-black rounded-full -translate-x-1/2"></div>
                    <div>
                      <h3 className="text-2xl font-helvetica font-bold text-black">
                        {event.year}
                      </h3>
                      <p className="text-lg font-helvetica font-light text-black leading-relaxed mt-2">
                        {event.event}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TimelineSection;
