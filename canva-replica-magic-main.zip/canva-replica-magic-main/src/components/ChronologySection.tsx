
import { useLanguage } from '@/hooks/useLanguage';

const ChronologySection = () => {
  const { t } = useLanguage();

  const chronologyEvents = [
    { year: '1751', event: t('timeline.1751') },
    { year: '1759', event: t('timeline.1759') },
    { year: '1762-1773', event: t('timeline.1762-1773') },
    { year: '1769', event: t('timeline.1769') },
    { year: '1784', event: t('timeline.1784') },
    { year: '1801', event: t('timeline.1801') },
    { year: '1829', event: t('timeline.1829') }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-6 lg:px-12">
        <h2 className="text-5xl lg:text-6xl font-helvetica font-bold text-black mb-12">
          {t('chronologyTitle')}
        </h2>

        <div className="relative max-w-4xl">
          <div className="absolute left-2 top-0 bottom-0 w-0.5 bg-black"></div>
          <div className="space-y-12">
            {chronologyEvents.map((event, index) => (
              <div key={index} className="relative pl-8">
                <div className="absolute left-0 w-4 h-4 bg-black rounded-full -translate-x-1/2"></div>
                <div>
                  <h3 className="text-2xl font-helvetica font-bold text-black mb-2">
                    {event.year}
                  </h3>
                  <p className="text-lg font-helvetica font-light text-black leading-relaxed">
                    {event.event}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ChronologySection;
